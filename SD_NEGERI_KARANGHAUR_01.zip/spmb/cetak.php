<?php
// Placeholder for cetak.php
?>